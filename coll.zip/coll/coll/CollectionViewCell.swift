//
//  CollectionViewCell.swift
//  coll
//
//  Created by bmiit on 20/03/24.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet var textlbl: UILabel!
}
