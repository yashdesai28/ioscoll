//
//  ViewController.swift
//  coll
//
//  Created by bmiit on 20/03/24.
//

import UIKit

class ViewController:UIViewController,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
  
    
    @IBOutlet var textlbl: [UILabel]!
    
    let student = ["yash","dev","vedu"]
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return student.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! CollectionViewCell
        cell.textlbl.text = student[indexPath.row]
        return cell
    }
    

    @IBOutlet var txtlbl: UILabel!
    @IBOutlet var colview: UICollectionView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        colview.dataSource = self
    }
    



}

